function mudarCor() {
  const cor = document.getElementById('corSelecionada').value;
  document.getElementById('textoColorido').style.color = cor; 
}
