// Função para atualizar o nome exibido
function atualizarNome() {
  // Obtém o elemento input
  let inputNovoNome = document.getElementById('novoNome');
  // Obtém o valor digitado no campo
  let novoNome = inputNovoNome.value;
  // Atualiza o conteúdo com o novo nome
  document.getElementById('resultado').textContent = "Nome atual: " + novoNome;
}